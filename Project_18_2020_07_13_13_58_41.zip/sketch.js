//Global Variables
var monkey, monkeyimg, bananaimg, bananaGroup, obstacleimg, obstacleGroup, backgroundj, backgroundimg, score, stoneimg, edges;
var score=0;


function preload(){
  backgroundimg=loadImage("jungle.jpg");
  monkeyimg= loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png");
  
  bananaimg=loadImage("Banana.png");
  obstacleimg=loadImage("stone.png");
  
  
  
}


function setup() {
  createCanvas(600,300);
  backgroundj=createSprite(200,200,400,400);
  backgroundj.addImage("bckgrnd",backgroundimg);
  backgroundj.velocityX=-4;
  backgroundj.scale=1.5;
  
  monkey=createSprite(50,250,15,15);
  monkey.addAnimation("run",monkeyimg);
  monkey.scale=0.1;
  
  bananaGroup=new Group();
  obstacleGroup=new Group();
}


function draw(){
 background(255);
  
  edges=createEdgeSprites();
   if(backgroundj.x<0){
    backgroundj.x=backgroundj.width/2;
   }
  
  if(keyDown("space")&&monkey.y>=255){
    monkey.velocityY=-14;
   }
  monkey.velocityY=monkey.velocityY+1;
  
  if(bananaGroup.isTouching(monkey)){
    score=score+10;
    bananaGroup.destroyEach();
  }
      switch(score){
      case 10: monkey.scale=0.11;
        break;
      case 20: monkey.scale=0.12;
        break;
        case 30: monkey.scale=0.13;
        break;
        case 40: monkey.scale=0.14;
        break;
        case 50: monkey.scale=0.15;
        break;
        default: break;
    }
  
  if(obstacleGroup.isTouching(monkey)){
    monkey.scale=0.1;
    score=0;
  }
  
  food();
  obstacle();
  
  
  monkey.collide(edges[3]);
  drawSprites();
  stroke("white");
  textSize(15);
  fill("white");
  text("Score: "+score,400,40);
}

function food(){
  if(frameCount%80===0){
    var banana=createSprite(600,200,20,20);
    banana.addImage("banan",bananaimg);
    banana.scale=0.05;
    banana.y=random(225,275);
    banana.velocityX=-5;
    banana.lifetime=120;
    bananaGroup.add(banana);
  }
  
}

function obstacle(){
  if(World.frameCount%100===0){
    var stone=createSprite(600,290,20,20);
    stone.addImage("stn",obstacleimg);
    stone.scale=0.1;
    stone.velocityX=-5;
    stone.lifetime=120;
    obstacleGroup.add(stone);
  }
  
  
  
}
